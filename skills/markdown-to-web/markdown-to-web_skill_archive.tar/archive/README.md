# markdown-to-web Skill Archive

**Archive created:** 2026-08-06  
**Archive contents:** All files produced and referenced during the markdown-to-web skill unification project

## Directory Structure

```
archive/
├── README.md (this file)
├── v4_deliverables/           # Final v4.0.0 deliverables
│   ├── markdown-to-web_SKILL_v4.md              # The unified v4.0.0 skill (3,667 lines)
│   ├── unified_skill_v4_IMPLEMENTATION_PLAN.md  # The v4.0.0 implementation plan (638 lines)
│   └── markdown-to-web_SKILL_v2.1.0.md          # Prior v2.1.0 deliverable (for reference)
├── source_drafts/             # All source documents reviewed
│   ├── original_SKILL.md                        # react-markdown-report v1.0.1 (the original)
│   ├── draft_z.md                               # draft_z v2.0.0 (validation-review spec)
│   ├── draft_z2.md                              # draft_z2 v2.0.0 (comprehensive, 3,153 lines)
│   ├── draft_q2.md                              # draft_q2 v2.0.0 (production-grade, 2,559 lines)
│   ├── draft_q3.md                              # draft_q3 v3.0.0 (BASE for v4.0.0, 1,822 lines)
│   ├── draft_d.md                               # draft_d v1.0.0 (config-system approach)
│   ├── draft_d2.md                              # draft_d2 v2.0.0 (config-system, 2,619 lines)
│   ├── draft_k.md                               # draft_k v2.0.0 (badge registry pattern)
│   └── coding_specialist_persona.txt            # The coding specialist persona (operating prompt)
├── implementation_plans/      # Implementation plan documents
│   └── v2.1.0_implementation_plan.md            # The original v2.1.0 implementation plan
└── v4_chunks/                 # The 5 chunk files used to build v4.0.0
    ├── chunk1_frontmatter_part1.md              # Front matter + Part 1 (747 lines)
    ├── chunk2_part2_sec1to9.md                  # Part 2 §1–§9 (1,298 lines)
    ├── chunk3_part2_sec10to15.md                # Part 2 §10–§15 (1,364 lines)
    ├── chunk4_part2_sec16to22.md                # Part 2 §16–§22 (515 lines)
    └── chunk5_appendices_closing.md             # Appendices A–F + Closing (703 lines)
```

## What's in v4.0.0

`markdown-to-web_SKILL_v4.md` is the unified, technically-correct skill file. It merges:
- **draft_q3.md** (BASE — only edition with correct Tailwind v4 `@theme` pattern and correct WCAG large-text contrast arithmetic)
- **draft_z2.md** (full test code, performance budgets, CI/CD, self-hosted fonts)
- **draft_d2.md** (full template CSS for technical + minimal, 6-week migration plan)
- **v2.1.0** (Part 1 validation review — unique, preserved)
- **original_SKILL.md v1.0.1** (evidence contract, anti-pattern format, z-index discipline)

## Bug Fixes (15 total — see Part 1 §21 and Appendix A)

Three Critical bugs present in prior editions are fixed:
1. `@theme`-in-`@media` (invalid Tailwind v4, dark mode silently fails) → fixed via two-layer token pattern (§6.1)
2. WCAG "14px relaxes AAA" arithmetic error (14px is not large text) → fixed, correct math in §10.1, high-contrast recipe in §10.5
3. `dangerouslySetInnerHTML` (XSS surface) → rejected, component-map pipeline in §8.5

Two High bugs:
4. AST badge/component disconnect → rejected, backtick-wrapping pattern in §8.5
5. Fence-blind regex → fixed via `fence.ts` scanner (§9.1)

Plus 10 Medium/Low fixes (see Appendix A for the full ledger).

## How to Rebuild v4.0.0 from Chunks

The v4.0.0 deliverable was built by concatenating the 5 chunk files in order:

```bash
cat v4_chunks/chunk1_frontmatter_part1.md \
    v4_chunks/chunk2_part2_sec1to9.md \
    v4_chunks/chunk3_part2_sec10to15.md \
    v4_chunks/chunk4_part2_sec16to22.md \
    v4_chunks/chunk5_appendices_closing.md \
    > markdown-to-web_SKILL_v4.md
```

To edit v4.0.0, modify the relevant chunk file and re-run the concatenation. The chunks are preserved for iterative editing without regenerating the whole document.

## File Inventory

| File | Lines | Purpose |
|------|-------|---------|
| markdown-to-web_SKILL_v4.md | 3,667 | Final unified v4.0.0 skill |
| unified_skill_v4_IMPLEMENTATION_PLAN.md | 638 | v4.0.0 implementation plan |
| markdown-to-web_SKILL_v2.1.0.md | 2,394 | Prior v2.1.0 deliverable (for reference) |
| original_SKILL.md | 628 | react-markdown-report v1.0.1 (original) |
| draft_z.md | 1,554 | draft_z v2.0.0 |
| draft_z2.md | 3,153 | draft_z2 v2.0.0 |
| draft_q2.md | 2,559 | draft_q2 v2.0.0 |
| draft_q3.md | 1,822 | draft_q3 v3.0.0 (BASE) |
| draft_d.md | 838 | draft_d v1.0.0 |
| draft_d2.md | 2,619 | draft_d2 v2.0.0 |
| draft_k.md | 807 | draft_k v2.0.0 |
| v2.1.0_implementation_plan.md | 329 | Original implementation plan |
| coding_specialist_persona.txt | 708 | Coding specialist persona |
| chunk1_frontmatter_part1.md | 747 | v4 chunk 1 |
| chunk2_part2_sec1to9.md | 1,298 | v4 chunk 2 |
| chunk3_part2_sec10to15.md | 1,364 | v4 chunk 3 |
| chunk4_part2_sec16to22.md | 515 | v4 chunk 4 |
| chunk5_appendices_closing.md | 703 | v4 chunk 5 |

**Total:** 18 files, ~25,000 lines of skill documentation
